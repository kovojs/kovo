import { createHash } from 'node:crypto';
export const d1PackageInstance = "d1-v6-authenticated-overlay";
const ownership = new WeakMap();
const makeFactory = (kind, owner) => (...args) => {
  const handle = Object.freeze({ args, kind });
  ownership.set(handle, Object.freeze({ ...owner, kind, packageInstance: d1PackageInstance }));
  return handle;
};
export const publicAccess = (reason) => Object.freeze({ kind: "public", reason });
const unbound = Object.freeze({ appId: "<unbound>", ownerKey: "<unbound>", providerKey: "<unbound>" });
export const endpoint = makeFactory("endpoint", unbound);
export const layout = makeFactory("layout", unbound);
export const mutation = makeFactory("mutation", unbound);
export const query = makeFactory("query", unbound);
export const route = makeFactory("route", unbound);
export const task = makeFactory("task", unbound);
const ownerKeyFor = (metadata) => `d1v6:${createHash("sha256").update(JSON.stringify({
  appId: metadata.appId,
  providerExportBinding: metadata.providerExportBinding,
  providerImportSpecifier: metadata.providerImportSpecifier,
  providerKey: metadata.providerKey,
})).digest("hex")}`;
export function createD1BoundFactories(metadata) {
  const owner = Object.freeze({
    appId: metadata.appId,
    ownerKey: ownerKeyFor(metadata),
    providerKey: metadata.providerKey,
  });
  return Object.freeze({
    endpoint: makeFactory("endpoint", owner),
    layout: makeFactory("layout", owner),
    mutation: makeFactory("mutation", owner),
    publicAccess,
    query: makeFactory("query", owner),
    route: makeFactory("route", owner),
    task: makeFactory("task", owner),
  });
}
export function inspectD1Ownership(value) {
  return value && typeof value === "object" ? ownership.get(value) ?? null : null;
}
export function defineKovo(options) {
  const factories = createD1BoundFactories(options);
  return Object.freeze({
    ...factories,
    appId: options.appId,
    assemble(registries) {
      const handles = Object.values(registries).flat();
      for (const handle of handles) {
        const observed = inspectD1Ownership(handle);
        if (!observed || observed.ownerKey !== ownerKeyFor(options)) {
          throw new TypeError("D1OWN001 mixed app or Kovo package handle refused before assembly.");
        }
      }
      return Object.freeze({ handleCount: handles.length, ownerKey: ownerKeyFor(options) });
    },
  });
}
