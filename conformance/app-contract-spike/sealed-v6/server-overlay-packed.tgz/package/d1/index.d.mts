export * from '../dist/index.mjs';
type Server = typeof import('../dist/index.mjs');
declare const d1Owner: unique symbol;
export interface D1BoundFactories<AppId extends string> {
  readonly [d1Owner]: AppId;
  readonly endpoint: Server['endpoint'];
  readonly layout: Server['layout'];
  readonly mutation: Server['mutation'];
  readonly publicAccess: Server['publicAccess'];
  readonly query: Server['query'];
  readonly route: Server['route'];
  readonly task: Server['task'];
}
export interface D1App<AppId extends string> extends D1BoundFactories<AppId> {
  readonly appId: AppId;
  assemble(input: Readonly<Record<string, readonly unknown[]>>): { readonly handleCount: number; readonly ownerKey: string };
}
export declare const d1PackageInstance: string;
export declare function createD1BoundFactories<const AppId extends string>(
  metadata: { readonly appId: AppId; readonly providerExportBinding: string; readonly providerImportSpecifier: string; readonly providerKey: string },
): D1BoundFactories<AppId>;
export declare function defineKovo<const AppId extends string>(
  options: { readonly appId: AppId; readonly db?: () => unknown; readonly env?: () => unknown; readonly provider: unknown; readonly providerExportBinding: string; readonly providerImportSpecifier: string; readonly providerKey: string },
): D1App<AppId>;
export declare function inspectD1Ownership(value: unknown):
  | { readonly appId: string; readonly kind: string; readonly ownerKey: string; readonly packageInstance: string; readonly providerKey: string }
  | null;
